create
    definer = admin@`%` procedure GetMenuSalesByDate(IN startDate date, IN endDate date)
BEGIN
    SELECT menuName, SUM(totalAmount) AS totalSales
    FROM menu AS m
             JOIN order_detail AS o2 ON m.menuId = o2.menuId
    WHERE DATE(o2.itemOrderTime) BETWEEN startDate AND endDate
    GROUP BY m.menuName;
END;

